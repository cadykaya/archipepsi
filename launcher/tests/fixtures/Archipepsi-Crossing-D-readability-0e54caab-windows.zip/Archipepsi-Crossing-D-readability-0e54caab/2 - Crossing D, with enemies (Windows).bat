@echo off
rem Crossing D, readability review build: the whole Crossing, the Upper
rem Yard's fight included. Joins the game's two parts first if no launcher
rem has yet.
cd /d "%~dp0"
if exist "Archipepsi-Crossing-D.exe" goto play
rem Delivered in two parts: join them into the game, once, and check it.
if not exist "Archipepsi-Crossing-D.exe.part1" goto missing
if not exist "Archipepsi-Crossing-D.exe.part2" goto missing
echo Joining the two parts into the game (once)...
copy /b "Archipepsi-Crossing-D.exe.part1" + "Archipepsi-Crossing-D.exe.part2" "Archipepsi-Crossing-D.exe" >nul
for %%F in ("Archipepsi-Crossing-D.exe") do set JOINED=%%~zF
if not "%JOINED%"=="30000" goto broken
del "Archipepsi-Crossing-D.exe.part1" "Archipepsi-Crossing-D.exe.part2"
:play
start "" "%~dp0Archipepsi-Crossing-D.exe"
exit /b 0
:missing
echo Unzip BOTH parts (part1of2 and part2of2) into this same folder,
echo then run this again.
pause
exit /b 1
:broken
echo The joined game is %JOINED% bytes, not 30000. Please download both
echo parts again.
del "Archipepsi-Crossing-D.exe"
pause
exit /b 1
