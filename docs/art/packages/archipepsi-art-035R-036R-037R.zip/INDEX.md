# Archipepsi art — the three post-030 revisions, 035-R / 036-R / 037-R

**All three PASSED** (owner, 2026-08-29), and the post-030 gap pass is now
fully reviewed:

| batch | verdict |
|---|---|
| 031 zone keys | **PASS** |
| 032 viewmodel + baseline melee | **PASS WITH BOUNDARY** |
| 033 Zone exit | **PASS AUDIT / BUILD NOTHING** |
| 034 hard gates | **PASS VISUAL PRINCIPLE** |
| 035-R recognition | **PASS** |
| 036-R secret cues | **PASS** |
| 037-R enemy surfaces | **PASS WITH DOCUMENTED CAVEAT** |
| boss audit | **ACCEPTED / BUILD NOTHING** |

This package is the three that were sent back and have now passed. It does
not repackage the four that passed first time.

**The art lane is now intentionally idle.** No Batch 038, no Echo visual
parts, no diegetic interface work, until the owner publishes the modular Echo
kitbash brief and the diegetic in-world interface brief.

### The caveat recorded against 037-R

Brute vs scuttler surface identity remains weak — the scuttler reads more
armoured than its description implies. **Accepted, not outstanding.** The
approved scuttler silhouette and body must **not** be altered solely to force
a stronger surface distinction; its silhouette already carries substantial
role identity, so surface may remain supporting information here. Revisit
only with gameplay evidence.

```
NNN-slug/
  sheets/   the review renders
  models/   the .glb assets and their manifest.json
  NOTES.md  the full working
```

## 035-R — recognition, raised to object scale

**Do both**, as instructed: raise the hand-scale tells *and* keep the
interaction hardware as a redundant cue.

The two failing pairs differed only by a hand-scale feature — 6 cm grips
against 3 cm mouldings, a 9 cm keyway against a scribed outline. **Both were
legal under the derived floor** (`min_feature_fraction` 0.08 of a 0.42 m
crate is 3.4 cm; 6 cm is ~7 screen px at 4.5 m) and both still failed. Two
pixels is enough to see that a form exists and nowhere near enough to tell
which form it is.

> **The rule adopted: a tell that has to survive gameplay distance must
> change the object's SILHOUETTE, not its surface.**

- **carryable vs fixed crate** — a bail arch with a hole through it, over
  feet with daylight under them, against a solid lifting boss on a crate
  sitting flush in a welded fillet.
- **key receiver vs welded hatch** — an open throat, two cheeks with the top
  open between them (a **fork** in the outline), against a flush slab with
  the beads run over the seam.
- **breakable vs blind panel** — shards at their own depths, broken in
  relief, against one flat coursed field.

The state plate is now **hardware**: recess, raised **bezel**, lit face inset
behind it. It survives greyscale, so it is a redundant cue rather than the
only one, and it needs no colour vision. Three independent channels:
silhouette = *what kind of thing*; interaction hardware = *yes this one is
operable*; state treatment = *what it is doing now*.

### Read `035-recognition-R/sheets/C_recognition_silhouette.png` first

Sheet A (plate lit) was solvable by spotting cyan. Sheet B suppresses the
emission and **still leaked**: the bezel is body geometry, no decoy has one,
so "find the bezel" solved it without using the grammar. Sheet C is flat
black on a lit backdrop — no material, no emission, no bezel, no colour.

It caught one more failure on sight: the first revised receiver closed its
throat with a lintel, and **a cavity in a front face does not break an
outline**. Opening the top fixed it. **All six pairs now separate in pure
silhouette**, weakest being breakable vs blind.

## 036-R — the secret cue package

No redesign, as instructed — the artifact was the problem.
`A_secret_cues.png` said EIGHT and visibly contained six because the panel
index was moved to four columns while the sheet WIDTH stayed at three, so
cues 4 and 8 were blitted off the right edge. It had been re-rendered and not
looked at. Fixed, verified by reading the image (2800 × 1080, eight cues
present), and NOTES.md rewritten to the current eight-cue state with the
history kept at the bottom.

## 037-R — enemy surfaces

Bodies and silhouettes **unchanged**, as instructed. The first pass told
armour from mechanism by *roughness*, which at mid range reads as shadow
rather than as a different kind of thing.

> **The difference is now carried by CONSTRUCTION.** `plate` is a slab seated
> proud of a recess; `mech` is ribbed and rodded. No role colours.

Two roles were also mislabelled and are **retagged**: the scuttler's carapace
and the beacon's head were tagged `plate` — the single largest mass on the
two roles captioned *"barely armoured at all"* and *"no armour at all"*.

`C_enemy_surfaces.png` is five role pairs at **4.0 m on one camera** — one
lens, one distance, one azimuth, level — plus a maximum-size detail. It took
three passes to be valid: a fixed standoff clipped the hovering drifter; a
standoff that *scaled* with the crown fixed the clipping and broke the sheet,
since a surface comparison shot from five distances is not a comparison; the
final version derives one distance from the widest pair, counting **depth**
in screen width (a 1.8 × 1.8 m brute is 2.24 m wide at a three-quarter
azimuth, and ran off its own left edge without it).

**Honest result: it reads in four of five pairs and in the detail.** The weak
pair is brute / scuttler — the caption claims "barely armoured at all" and
the scuttler still reads as a fairly solid dome. The retag is the honest half
of the fix; the other half is a body change, which is out of scope by
instruction. Recorded, not worked around.

## Requirement 31 is still untouched and still not worked around

Seven enemy roles have a body, a collider, a telegraph seat and now a
role-specific surface, and no way to be spawned: `ENEMY_ARCHETYPES` is still
`("melee", "ranged", "brute")`. Engineering truth for a Production slice.

## Verification at the time of packaging

| check | result |
|---|---|
| `tools/check_art_current.sh` | PASS — every generated asset rebuilds byte-identical |
| `tools/blender/check_docs_metrics.py` | PASS — 241 of 241 built assets quoted and verified |

That proves technical validity, which is the floor, not that the art is good.
