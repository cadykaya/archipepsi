# Capacity, arrivals, lettering — and "leaf" is not "dead end"

**Arty**

*2026-09-13. PROPOSALS. Nothing approved, nothing promoted. The
Triad/Terminus polish is **not** a Playable 0.3 requirement.*

**`HANDOFF.md` is the delivery.**

```
terminus/  THE DEAD-END TREATMENT, against what the graph actually does.

  "Leaf" in this implementation can still host onward branches, so the
  room has two states and they are not the same picture. Production's
  `dead_ends` is a measured adjacency count; Art's `dead_end` is a
  shape tag describing the end wall, and nothing in Production reads it.

  1  degree 1, both branches sealed  ->  the line stops here
  2  degree 2, one branch open       ->  PIXEL-IDENTICAL to frame 1
  3  degree 2, from inside           ->  plainly a way on

  0 of 921,600 pixels differ between 1 and 2, and the seal count is 2
  against 1, so the closure ran -- the 8 m mouth simply hides both side
  openings until you are inside. The treatment is a claim about the
  CHANNEL stopping, not about the room's degree.

lettering/  The repair, on the path the engine actually runs.

  An authored .glb NEVER receives ThemeMaterials: ContentInstantiator
  calls scene.instantiate() and contains "material" zero times;
  chamber_builders.gd names ThemeMaterials 46 times. The earlier frame
  captioned "the production material binding" was this harness swapping
  materials the engine never swaps. THE MATERIAL-CHANGE REQUEST IS
  WITHDRAWN -- do not implement it.

  A1 south board  A2 north placard (opposite face)  A3/A4 room yawed 37
  all read SEC 04.  B is kept and relabelled as the PROCEDURAL path's
  defect, which is real and is not this batch's.

evidence/ arrivals.json   10 openings, each with its own named region
          binding_whole   6 themes through Production's ThemeMaterials
          route_walk.json 11 routes, and where each jump was
views/    the furnished Cross.  study/  its two earlier states.
```

**The red capsules are occupancy stand-ins** — three per declared
`enemy_spawn` VOLUME, and the shells declare no spawn points at all.

**Still open and not Art's:** `shell_bay_terminus` cannot be composed at
all today. `compose_chain` returns no edges when any chamber lacks the
literal `entry`+`exit` pair, and `compose_with_branch` calls it first —
so one destination room seals every room's doors in the Zone.
