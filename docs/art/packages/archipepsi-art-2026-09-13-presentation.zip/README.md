# Presentation study, the binding proof, and three moved facts

**Arty**

*2026-09-13. Everything in here is a PROPOSAL. Nothing is approved.*

Open **`REPORT.md`** first — its image references resolve inside this
archive.

```
REPORT.md       the study, the proof, and the reconciliation
SPAN_REPLY.md   the reply to Prod correcting the "three risers short"
                diagnosis, and what the capsule numbers are not

views/          shell_junction_cross, final. FIVE images, every one
                stamped PREVIEW ONLY -- STAGED, NOT GENERATED
  1_the_approach          from the entry arm
  2_the_decision_point    6 m out, aimed at the machine's east corner
  3_the_working_bay       the 7.5 m side, with its working face
  4_the_service_passage   the 2.5 m side, with its declared spawns in it
  5_the_west_branch       the only angle the trunk lines read from

study/          the same room, the two states before. The argument is
                the sequence, so these are kept rather than deleted
  STAGE1  plant centred -- a corridor bent into a square. Furnishing it
          did not help and was not going to
  STAGE2  plant off centre -- the plan works, and it STILL read as a
          hallway from inside, which is why there is a stage 3

evidence/       binding_whole.json          6 themes, every required role
                control_missing_required    theme disqualified, nothing bound
                control_mismatched_digest   clause 4 refuses a wrong file
                control_missing_optional    ceiling falls back to wall
                route_walk.json             11 routes, and where each jump was
```

**The props are not decoration.** Every one stands at a point the shell
declares — a `cover` socket, a `reactive` socket, an `objective` volume,
an `enemy_spawn` volume — and each names a consumer that runs today.
Nothing was scattered to fill space. If a room looks empty here, it IS
empty to the runtime, and that is the finding.

**The lighting is the shipped Zone's** — ambient 0.35, fog 0.012, one
shadowless omni per fixture at range 12.0, and no directional light,
because a built Zone has none.

**Stills are stills.** They show framing, legibility and occupancy. They
do not show combat visibility and they do not show flicker-free motion.
