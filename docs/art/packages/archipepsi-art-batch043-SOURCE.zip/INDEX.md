# Batch 043 — SOURCE

Arty, 2026-09-11. Everything needed to rebuild the batch. Paths are
repository-relative; unzip over a checkout of the art branch at the revision
named in `PROVENANCE.txt` and the three commands below reproduce it.

## Rebuild

```
# 1. the status kit  (Glyph -> png/ -> SHEET_*.png)
GLYPH_ROOT=/path/to/ecms-glyph node \
    docs/art/review/status_2026-09-11/author_status_kit.mjs
python3 docs/art/review/status_2026-09-11/make_sheets.py
tools/content/run_status_preview.sh

# 2. the machinery kit  (Glyph -> Blender -> Godot)
GLYPH_ROOT=/path/to/ecms-glyph node \
    docs/art/review/machinery_2026-09-11/author_conduit_states.mjs
.tools/blender/blender -b --python tools/blender/build_machinery.py -- \
    docs/art/review/machinery_2026-09-11
tools/content/run_machinery_preview.sh

# 3. the physics props  (Blender -> Godot)
.tools/blender/blender -b --python tools/blender/build_physics_props.py
tools/content/run_props_preview.sh
```

Every preview runner needs `xvfb-run` and the Compatibility renderer;
`--headless` gives the dummy driver and every capture comes back black.

## Dependencies inside this archive

The two Glyph authoring scripts import `@glyph/protocol` and
`@glyph/core` from an ECMS Glyph checkout at `GLYPH_ROOT`, which is **not**
in this archive — it is a separate repository. The revision used is in
`PROVENANCE.txt`.

`tools/blender/build_machinery.py` and `build_physics_props.py` import
`tools/blender/common.py`, `brushkit.py`, `propkit.py` and `palette.py`, all
four of which are here, and read `assets/art_palette.json` and
`assets/art_budgets.json`, which are here too.

The three preview scripts under `tools/content/` load
`tools/artpreview/artbench.gd`, which is
here, and read the shipped `shell_corner_left` scene and the Batch 042
derelict fields from the repository — those are NOT in this archive, because
they are existing approved content rather than anything this batch authored.

## What is here

| | |
| --- | --- |
| `docs/art/review/status_2026-09-11/status_bodies.mjs` | the 21 hand-drawn silhouettes — the file to edit |
| `docs/art/review/status_2026-09-11/status_frames.mjs` | the five frames and the depletion track |
| `docs/art/review/status_2026-09-11/author_status_kit.mjs` | authors every Glyph project, exports every PNG |
| `docs/art/review/status_2026-09-11/make_sheets.py` | regenerates every review sheet |
| `docs/art/review/status_2026-09-11/glyph/` | 70 editable Glyph projects |
| `docs/art/review/status_2026-09-11/png/` | 71 individual transparent exports |
| `docs/art/review/status_2026-09-11/status_kit.json` | ids, families, sentences, targets, durations, native sizes, depletion tracks |
| `docs/art/review/machinery_2026-09-11/author_conduit_states.mjs` | the channel and the five state bands |
| `docs/art/review/machinery_2026-09-11/glyph/` | 6 editable Glyph projects |
| `docs/art/review/machinery_2026-09-11/conduit_states.json` | per state: brightness, pattern, motion, and the audio still required |
| `tools/blender/build_machinery.py` | the three machinery pieces |
| `tools/blender/build_physics_props.py` | the four object classes |
| `tools/blender/common.py` | the exporter, including this batch's `parts=`, `set_origin_group` and `assert_budget_group` |
| `assets/models/batch043/` | the exported `.glb` files and both manifests |
| `assets/textures/batch043/` | the baked prop and machinery textures |
| `tools/content/inspect_glb_nodes.py` | what a `.glb` offers a runtime after import |
| `tools/content/package_batch043.py` | this archive's own build script |

## Asset metadata

`assets/models/batch043/physics/manifest.json` carries, per candidate: the
class, mass, derived `mass_class`, carriable and manipulable flags, exported
size, triangle count, texel density, anchor, orientation, material roles,
attachment-point positions and normals, and the statement that every
dimension is a proposed art dimension and no collision exists.

`assets/models/batch043/machinery/manifest.json` carries the band tile in
pixels and metres, the addressable part names per asset, and the
`how_to_drive` contract.
