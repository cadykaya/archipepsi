# Capacity, arrivals, and two claims withdrawn

**Arty**

*2026-09-13. Everything here is a PROPOSAL. Nothing is approved, nothing
is promoted, and the Triad and Terminus polish is **not** a requirement
for finishing Playable 0.3.*

**Open `HANDOFF.md` first** — it is the delivery. `REPORT.md` is this
morning's presentation study, kept as evidence with its wrong claims
struck in place rather than edited away.

```
HANDOFF.md      the corrected capacity and arrival handoff, and the
                remaining integration findings
REPORT.md       the presentation study, with a correction box at the top
SPAN_REPLY.md   the reply to Prod on the basin stairs

views/          shell_junction_cross, furnished. PREVIEW ONLY -- STAGED,
                NOT GENERATED, on every frame
study/          the two earlier states of the same room

labels/   the mirrored-stencil finding, as a matched pair from one camera
  _A_glb_materials    the .glb's own materials  -> reads "SEC 04"
  _B_themematerials   ThemeMaterials, triplanar -> reads mirrored
          A UV repair reaches A and cannot reach B. Triplanar projects in
          the shader from world position and ignores mesh UVs, so the
          runtime fix is a material decision, not a projection one.

evidence/ arrivals.json               10 openings, each with its own
                                      named region, supported, clear and
                                      walked into the room from
          binding_whole.json          6 themes through PRODUCTION'S
                                      ThemeMaterials; pixels identical to
                                      the authored PNGs after the import
          control_missing_required    one row removed via their own
                                      _descriptor_override: that ROLE
                                      falls back, nothing else changes
          route_walk.json             11 routes, and where each jump was
```

**The red capsules are occupancy stand-ins.** Three are drawn per
declared `enemy_spawn` VOLUME — three is the harness's number, and the
shells declare no spawn points at all. Every other prop stands at a point
the shell declares, and nothing is scattered to fill space.

**The lighting is the shipped Zone's** — ambient 0.35, fog 0.012, one
shadowless omni per fixture at range 12.0, no directional light.

**Stills are stills.** The next useful evidence is the room operating in
the game, and the service passage's encounter is handed to Prod for a
real-player, real-enemy test rather than argued from a picture.
