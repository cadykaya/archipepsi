# Capacity, arrivals, and a lettering premise withdrawn

**Arty**

*2026-09-13. PROPOSALS. Nothing approved, nothing promoted, and the
Triad/Terminus polish is **not** a Playable 0.3 requirement.*

**`HANDOFF.md` is the delivery.** `REPORT.md` is the morning's study,
kept as evidence with its wrong claims struck in place rather than
edited away.

```
lettering/  The repair, proved on the path the engine actually runs.

  An authored .glb NEVER receives ThemeMaterials. ContentInstantiator
  calls scene.instantiate() and the file contains "material" zero
  times; chamber_builders.gd names ThemeMaterials 46 times. The frame
  captioned "the production material binding" in the previous delivery
  was this harness swapping materials the engine never swaps -- a true
  picture of a path these rooms do not take. Withdrawn.

  A1  the south gauge board, head-on          -> SEC 04
  A2  the north placard, the OPPOSITE face    -> SEC 04
  A3  A1 with the ROOM YAWED 37 degrees       -> SEC 04
  A4  A2 with the room yawed 37 degrees       -> SEC 04
  B   ThemeMaterials + triplanar -- KEPT and RELABELLED as the
      PROCEDURAL path's defect, which is real and is not this batch's

  Ordinary wall and floor tiling is in every frame and unchanged. The
  flip touches the positive-normal face only -- a sign has two faces
  and the projection mirrors exactly one -- and the build asserts each
  flipped face's U span is unchanged, so orientation moved and texel
  scale did not.

evidence/ arrivals.json    10 openings, each with its own named region,
                           supported, clear, walked into the room from
          binding_whole    6 themes through Production's ThemeMaterials
          control_missing  one row removed via their own seam
          route_walk.json  11 routes, and where each jump was

views/    the furnished Cross. STAGED, NOT GENERATED on every frame; the
          red capsules are occupancy stand-ins, three per declared
          VOLUME, and the shells declare no spawn points at all
study/    the two earlier states of the same room
```

**Still open, and not Art's:** `shell_bay_terminus` cannot be composed at
all today — `compose_chain` returns no edges when any chamber lacks the
literal `entry`+`exit` pair, and `compose_with_branch` calls it first, so
one destination room seals every room's doors. A leaf is refused before
it can become a leaf. No `exit` has been fabricated and no door cut.
