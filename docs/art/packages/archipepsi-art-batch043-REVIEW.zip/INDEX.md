# Batch 043 — REVIEW

Arty, 2026-09-11. Everything here is a PROPOSAL: nothing is approved, nothing
is bound to runtime, no mechanic is implemented, and the playable build is
unchanged.

## Read in this order

1. `docs/art/reports/2026-09-11-batch043.md` — the report.
2. `docs/art/review/status_2026-09-11/DECISIONS_FOR_OWNER.md` — the five
   things that genuinely need you.
3. `docs/art/BATCH_043_INVENTORY.md` — what already existed, before anything
   new was made.

## The status kit

`docs/art/review/status_2026-09-11/README.md`, then:

| sheet | |
| --- | --- |
| `SHEET_markers.png` | all 21 markers on three grounds |
| `SHEET_markers_grayscale.png` | the same, hue removed |
| `SHEET_native_size.png` | 1:1 — the sheet that answers the actual question |
| `SHEET_pairs.png` | the six pairs that must not be confused |
| `SHEET_frames.png` | the four family frames and the compound frame |
| `SHEET_components.png` | duration, the player tick, the compound hint |

In the room, under the shipped light model, on bright concrete, dark derelict
and a visually busy background: `room/STATUS_individual_*`,
`room/STATUS_compound_*`, `room/STATUS_crowd_*`, grayscale companions, and
`room/SEQ_compound_forming.gif` with its twelve frames as stills.

## Machinery feedback

`docs/art/review/machinery_2026-09-11/README.md`, then `_look_states.png` for
the five states flat, `room/MACH_five_states.png` on a wall,
`room/MACH_close_inactive_vs_blocked.png` for the pair that has to be settled
by pattern alone, `room/MACHSEQ_motion.gif` for travel against growth, and
`room/MACH_switch_*.png` for the setter and receiver.

**No audio exists in this kit** and no frame here demonstrates any.

## The physics props

`docs/art/review/props_2026-09-11/CLASS_MAP.md` maps all twelve of Design 2
§10.1's classes; four are built. `room/PROPS_lineup.png`,
`room/PROPS_manipulable_vs_decorative.png`, and one close frame per candidate.

## What these pictures do not show

Static frames and two short loops. They do not prove combat visibility, they
do not prove the markers are flicker-free in motion, and they do not prove
readability while the player is turning.

Editable sources, Glyph projects, Blender scripts, exported models and the
preview scripts are in the **SOURCE** archive, not this one.
