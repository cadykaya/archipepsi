# Batch 043 — REVIEW

Arty, 2026-09-11. Everything here is a PROPOSAL: nothing is approved, nothing
is bound to runtime, no mechanic is implemented, and the playable build is
unchanged.

## Read in this order

1. `docs/art/reports/2026-09-11-batch043.md` — the report.
2. `docs/art/review/status_2026-09-11/DECISIONS_FOR_OWNER.md` — the five
   things that genuinely need you.
3. `docs/art/BATCH_043_INTEGRATION.md` — the handoff: every addressable node,
   how to drive it, what each coordinate means, and the six checks.
4. `docs/art/BATCH_043_INVENTORY.md` — what already existed, before anything
   new was made.

## The status kit

`docs/art/review/status_2026-09-11/README.md`, then:

| sheet | |
| --- | --- |
| `SHEET_markers.png` | all 21 markers on three grounds |
| `SHEET_markers_grayscale.png` | the same, hue removed |
| `SHEET_native_size.png` | 1:1 — the sheet that answers the actual question |
| `SHEET_pairs.png` | the six pairs that must not be confused |
| `SHEET_frames.png` | the four family frames and the compound frame |
| `SHEET_components.png` | duration, the player tick, the compound hint |

In the room, under the shipped light model, on bright concrete, dark derelict
and a visually busy background: `room/STATUS_individual_*`,
`room/STATUS_compound_*`, `room/STATUS_crowd_*`, grayscale companions, and
`room/SEQ_compound_forming.gif` with its twelve frames as stills.

## Machinery feedback

`docs/art/review/machinery_2026-09-11/README.md`, then `_look_states.png` for
the five states flat, `room/MACH_five_states.png` on a wall,
`room/MACH_close_inactive_vs_blocked.png` for the pair separated by
brightness **and** pattern, `room/MACHSEQ_motion.gif` for travel against
growth, `room/MACH_delay_*.png` for a labelled 4.0 s delay with both
endpoints, `room/MACH_hinge_sweep.png` and `.gif` for the lever's fixed
pintle, and `room/MACH_switch_*.png` for the setter and receiver.

**No audio exists in this kit** and no frame here demonstrates any — but the
filling band, not the audio, is §19.5's primary timing channel and it is
delivered.

## The physics props

`docs/art/review/props_2026-09-11/CLASS_MAP.md` — **all twelve** of Design 2
§10.1's classes, all built. `room/PROPS_lineup_bright.png` and `_dark.png`
are the family in three rows split at the 60 kg carry line, under both
lighting conditions; `room/PROPS_candidate_vs_decorative_*.png` settles the
`GENERIC` / `DRUM` question; `room/PROPS_fixed_vs_movable_*.png` shows
`ANCHOR_BLOCK` reading as `FIXED`; and there is one close frame per class.

## What these pictures do not show

Static frames and two short loops. They do not prove combat visibility, they
do not prove the markers are flicker-free in motion, and they do not prove
readability while the player is turning.

Editable sources, Glyph projects, Blender scripts, exported models and the
preview scripts are in the **SOURCE** archive, not this one.
